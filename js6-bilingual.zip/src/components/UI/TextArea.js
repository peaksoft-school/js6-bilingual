import React from "react";

import { TextareaAutosize } from "@mui/material";

const TextArea = ({ children, sx }) => {
    return <TextareaAutosize sx={sx}>{children}</TextareaAutosize>;
};

export default TextArea;
