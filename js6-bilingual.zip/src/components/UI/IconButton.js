import { IconButton } from "@mui/material";
import React from "react";
import styled from "styled-components";

const IconButton = ({ children, size, sx }) => {
    return (
        <StyledIcon size={size} sx={sx}>
            {children}
        </StyledIcon>
    );
};

export default IconButton;

const StyledIcon = styled(IconButton)`
    &.MuiIconButton-root {
        border-color: #9a9a9a;
    }
`;
