import React from "react";

// import AccessAlarmIcon from "@mui/icons-material/AccessAlarm";

// import AddIcon from "@mui/icons-material/Add";

import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";

import PauseCircleOutlineOutlinedIcon from "@mui/icons-material/PauseCircleOutlineOutlined";

import PlayCircleFilledWhiteOutlinedIcon from "@mui/icons-material/PlayCircleFilledWhiteOutlined";

import TaskOutlinedIcon from "@mui/icons-material/TaskOutlined";

import { IconButton } from "@mui/material";

import TextArea from "components/UI/TextArea";

// import StyledButton from "components/UI/Button";

const App = () => {
    return (
        <div>
            <TextArea
                sx={{
                    color: "#9a9a9a",
                }}
            />
            <IconButton
                edge="start"
                sx={{
                    "&:hover": {
                        color: "#F61414",
                    },
                }}
                size="large">
                <TaskOutlinedIcon />
            </IconButton>
            <IconButton
                edge="start"
                sx={{
                    color: "#2AB930",
                }}
                size="large">
                <DeleteOutlinedIcon />
            </IconButton>
            <IconButton
                edge="start"
                sx={{
                    color: "#7B61FF",
                    display: "flex",
                    justifyContent: "column",
                    "&:hover": {
                        background: "#7B61FF",
                        color: "#fffff",
                    },
                }}
                size="large">
                <PlayCircleFilledWhiteOutlinedIcon />
            </IconButton>
            <IconButton
                edge="start"
                sx={{
                    color: "#7B61FF",
                    display: "flex",
                    justifyContent: "column",
                    "&:hover": {
                        background: "#7B61FF",
                        color: "#fffff",
                    },
                }}
                size="large">
                <PauseCircleOutlineOutlinedIcon />
            </IconButton>
            {/* <StyledButton icon={<AddIcon />} variant="contained" color="primary">
                add new text
            </StyledButton> */}
        </div>
    );
};

export default App;
